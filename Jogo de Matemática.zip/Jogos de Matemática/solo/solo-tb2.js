var score;
score = 0;
alert("Bem vindo!");


var q1;
q1 = prompt("2x8");
if (q1 == "16") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro!vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q2;
q2 = prompt("2x9");
if (q2 == "18") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro!vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q3;
q3 = prompt("2x1");
if (q3 == "2") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro!vá até o final, Atualize a página e tente de novo!")
}
var q4;
q4 = prompt("2x10");
if (q4 == "20") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro!vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q5;
q5 = prompt("2x7");
if (q5 == "14") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro!vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q6;
q6 = prompt("2x4");
if (q6 == "8") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro!vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q7;
q7 = prompt("2x2");
if (q7 == "4") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro!vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q8;
q8 = prompt("2x3");
if (q8 == "6") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro!vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q9;
q9 = prompt("2x5");
if (q9 == "10") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro!vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q10;
q10 = prompt("2x6");
if (q10 == "12") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro!vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}