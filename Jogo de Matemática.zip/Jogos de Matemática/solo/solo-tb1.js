var score;
score = 0;
alert("Bem vindo!");


var q1;
q1 = prompt("1x7");
if (q1 == "7") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q2;
q2 = prompt("1x9");
if (q2 == "9") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q3;
q3 = prompt("1x1");
if (q3 == "1") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q4;
q4 = prompt("1x10");
if (q4 == "10") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q5;
q5 = prompt("1x8");
if (q5 == "8") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q6;
q6 = prompt("1x4");
if (q6 == "4") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q7;
q7 = prompt("1x2");
if (q7 == "2") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q8;
q8 = prompt("1x3");
if (q8 == "3") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q9;
q9 = prompt("1x5");
if (q9 == "5") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q10;
q10 = prompt("1x6");
if (q10 == "6") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}