var score;
score = 0;
alert("Bem vindo!");


var q1;
q1 = prompt("10x7");
if (q1 == "70") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}

var q2;
q2 = prompt("10x9");
if (q2 == "90") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}

var q3;
q3 = prompt("10x1");
if (q3 == "10") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}

var q4;
q4 = prompt("10x10");
if (q4 == "100") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}

var q5;
q5 = prompt("10x8");
if (q5 == "80") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}

var q6;
q6 = prompt("10x4");
if (q6 == "40") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}

var q7;
q7 = prompt("10x2");
if (q7 == "20") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}

var q8;
q8 = prompt("10x3");
if (q8 == "30") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}

var q9;
q9 = prompt("10x5");
if (q9 == "50") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}

var q10;
q10 = prompt("10x6");
if (q10 == "60") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}