var score;
score = 0;
alert("Bem vindo!");


var q1;
q1 = prompt("9x7");
if (q1 == "63") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q2;
q2 = prompt("9x9");
if (q2 == "81") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q3;
q3 = prompt("9x1");
if (q3 == "9") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q4;
q4 = prompt("1x10");
if (q4 == "90") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q5;
q5 = prompt("9x8");
if (q5 == "72") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q6;
q6 = prompt("9x4");
if (q6 == "36") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q7;
q7 = prompt("9x2");
if (q7 == "18") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q8;
q8 = prompt("9x3");
if (q8 == "27") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q9;
q9 = prompt("9x5");
if (q9 == "45") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q10;
q10 = prompt("9x6");
if (q10 == "54") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}