var score;
score = 0;
alert("Bem vindo!");


var q1;
q1 = prompt("4x7");
if (q1 == "28") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q2;
q2 = prompt("4x9");
if (q2 == "36") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q3;
q3 = prompt("4x1");
if (q3 == "4") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q4;
q4 = prompt("4x10");
if (q4 == "40") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q5;
q5 = prompt("4x8");
if (q5 == "32") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q6;
q6 = prompt("4x4");
if (q6 == "16") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q7;
q7 = prompt("4x2");
if (q7 == "8") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q8;
q8 = prompt("4x3");
if (q8 == "12") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q9;
q9 = prompt("4x5");
if (q9 == "20") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q10;
q10 = prompt("4x6");
if (q10 == "24") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}