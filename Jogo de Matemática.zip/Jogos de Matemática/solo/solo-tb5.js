var score;
score = 0;
alert("Bem vindo!");


var q1;
q1 = prompt("5x5");
if (q1 == "25") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q2;
q2 = prompt("5x9");
if (q2 == "45") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q3;
q3 = prompt("5x1");
if (q3 == "5") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q4;
q4 = prompt("5x10");
if (q4 == "50") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q5;
q5 = prompt("5x8");
if (q5 == "40") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q6;
q6 = prompt("5x4");
if (q6 == "20") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q7;
q7 = prompt("5x2");
if (q7 == "10") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q8;
q8 = prompt("5x3");
if (q8 == "15") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q9;
q9 = prompt("5x7");
if (q9 == "35") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}
var q10;
q10 = prompt("5x6");
if (q10 == "30") {
    score++;
    alert("Acerto miseravi score:" + score);
} else {
    alert("Erro! vá até o final, Atualize a página e tente de novo!")
    const btn = document.querySelector('#refresh')
    btn.addEventListener('click', () => {
        location.reload()
    })
}